Default Keymap
===

Super simple default keymap.

Keymap Maintainer: [hidsh](https://github.com/hidsh)

Intended usage: This is mostly provided for testing before you build your own keymap and as a reference to a stock(ish) configuration
